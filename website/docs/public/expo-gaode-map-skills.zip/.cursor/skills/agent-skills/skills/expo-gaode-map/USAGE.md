# AI 辅助开发指南 (AI-Assisted Development Guide)

欢迎使用 `expo-gaode-map`！为了让你在开发地图功能时拥有“开挂”般的体验，我们专门为 **Cursor / Trae** 等 AI 编程助手准备了一套深度集成的**技能知识库 (Skills)**。

这些文件位于 `.cursor/skills/` 目录下，它们不仅是文档，更是 AI 助手的“大脑插件”。

## 🌟 这能为你带来什么？

当你使用 AI 助手（如 Cursor 的 Composer 或 Trae 的 Agent）编写地图代码时，这些技能文件将确保：
- **API 零差错**：AI 将精准调用本库的 API，彻底杜绝“凭空捏造”方法名的情况。
- **性能方案最优**：AI 会自动建议你使用 C++ 聚合引擎或轨迹抽稀工具，而不是低效的 JS 方案。
- **平台差异自动处理**：AI 清楚 Android 和 iOS 在定位权限、前台服务上的不同配置要求。

## �️ 如何在开发中使用？

如果你正在使用 Cursor 或 Trae，可以通过以下方式让 AI 更好地辅助你：

### 1. 任务式引导 (Mention Skills)
在对话框中输入 `@` 并搜索对应的技能文件名，让 AI 针对特定任务“加载知识”：
- **需要高性能 Marker？** -> 输入 `@marker-and-clustering.md`
- **需要做地理围栏判断？** -> 输入 `@geometry-utils.md`
- **需要配置后台定位？** -> 输入 `@location-and-tracking.md`

### 2. 全局提效 (Composer / Agent)
在进行复杂功能开发（如：实现一个打车软件的地图交互）时，直接告诉 AI：
> “参考 @SKILL.md 中的规范，帮我实现一个带路径规划和实时定位平滑移动的地图页面。”

## � 技能模块速查

| 模块名称 | 适用场景 |
| :--- | :--- |
| **[map-view-core.md](./references/map-view-core.md)** | 基础地图显示、相机控制（缩放、旋转、移动）。 |
| **[marker-and-clustering.md](./references/marker-and-clustering.md)** | 海量点聚合、自定义标记点、点击交互。 |
| **[geometry-utils.md](./references/geometry-utils.md)** | **(推荐)** 坐标转换、距离/面积计算、轨迹抽稀、空间关系判断。 |
| **[location-and-tracking.md](./references/location-and-tracking.md)** | 定位蓝点、权限请求、Android 前台服务配置。 |
| **[navigation.md](./references/navigation.md)** | 驾车/步行/骑行路径规划、原生导航视图。 |
| **[search.md](./references/search.md)** | POI 搜索、逆地理编码（坐标转地址）。 |
| **[web-api.md](./references/web-api.md)** | 纯数据层面的高德 Web 服务集成。 |

## 💡 开发者贴士
虽然这些文件主要是给 AI 看的，但如果你需要快速查看某个 API 的正确参数格式，直接打开对应的 `.md` 文件通常比翻阅 TypeScript 类型定义或官方文档更直观、更高效。

---
*让 AI 成为你的高德地图专家，开启高效开发之旅。*
