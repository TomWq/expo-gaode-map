# Claude 使用指南

如果你使用 Claude (如 Claude.ai 或 Claude Code) 进行开发：

1. **项目上下文**：将 `skills/expo-gaode-map/` 目录下的内容添加到你的项目知识库中。
2. **系统提示词**：你可以告知 Claude 遵循这些技能规范，以确保它生成的 API 代码与本项目完全一致。
3. **详细指令**：参考 [AGENTS.md](./AGENTS.md) 获取更多关于如何与 AI 协作的技巧。
