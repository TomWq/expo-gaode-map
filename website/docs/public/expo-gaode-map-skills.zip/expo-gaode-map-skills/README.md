# Expo Gaode Map AI Skills

## 安装方法

1. 将此目录下的 `.cursor` 文件夹直接复制到您的项目根目录中。
2. 如果您使用的是 Trae 或 Cursor，它将自动加载这些地图开发相关的专业技能库。
